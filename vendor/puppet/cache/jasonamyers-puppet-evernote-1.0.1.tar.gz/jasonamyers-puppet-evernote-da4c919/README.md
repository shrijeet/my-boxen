# Evernote Puppet Module for Boxen

## Usage

```puppet
include evernote
```

## Required Puppet Modules

* boxen

