# CloudApp Puppet Module for Boxen

CloudApp allows you to share images, links, music, videos and files.

See http://getcloudapp.com/ for more

## Usage

```puppet
include cloudapp
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
